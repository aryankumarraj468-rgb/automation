# AutoSuite

One toolkit, two interfaces (CLI + Tkinter GUI), five automation tools. Pure standard library (Python 3.8+); `psutil` is optional.

| Tool | What it does |
|------|--------------|
| **organize** | Sort files by type / date / extension, preview with dry-run, undo, find & quarantine duplicates |
| **scrape** | Extract title, text, links, images, headings, tables, meta from a page; save as JSON/CSV/TXT; honours robots.txt |
| **email** | Send mail with attachments/HTML, or CSV mail-merge with `$placeholders` |
| **monitor** | CPU / memory / disk snapshot, live watch with CSV logging, threshold alerts, website checks |
| **schedule** | Persistent interval/daily jobs running any of the tools (or shell commands) via a daemon |

## Quick start
```bash
python -m autosuite gui                     # graphical interface
python -m autosuite --help                  # command line
pip install -e .                            # optional: gives `autosuite` / `autosuite-gui` commands
pip install psutil                          # optional: richer monitoring
```
Run tests: `python -m unittest discover -s tests`

## CLI examples
```bash
autosuite organize ~/Downloads --by type --dry-run
autosuite organize ~/Downloads --by date -r
autosuite organize --undo
autosuite dupes ~/Pictures --move-to ~/dupes -n

autosuite scrape https://example.com --what links -o links.csv
autosuite scrape https://example.com/table --what tables -o tables.csv

autosuite email setup                       # SMTP host/user/from (saved to config)
export AUTOSUITE_SMTP_PASSWORD='app-password'
autosuite email send --to a@b.com --subject Hi --body "Hello" --attach report.pdf -n
autosuite email bulk examples_recipients.csv --subject "Hello $name" --body-file letter.txt -n

autosuite monitor status
autosuite monitor watch --interval 5 --log ~/sys.csv
autosuite monitor urls https://example.com https://python.org

autosuite schedule add tidy organize --daily 18:00 --arg source=~/Downloads --arg by=type
autosuite schedule add health monitor --every 10m --arg email_to=me@example.com
autosuite schedule add backup shell --daily 02:30 --arg "command=rsync -a ~/docs /backup"
autosuite schedule list | run <name> | enable/disable/remove <name> | history
autosuite schedule daemon                   # keep running (use systemd / Task Scheduler / tmux)
```

## Data and security
- Everything lives in `~/.autosuite` (`AUTOSUITE_HOME` to change): `config.json`, `jobs.json`, `undo.json`, `history.log`.
- The SMTP password is **never written to disk**; it is read from the env var named in `password_env`.
- Gmail/Outlook need an app password. Always try `--dry-run` first for email and organize.
- `shell` jobs run arbitrary commands as you; only add jobs you trust.
- Scraping: respect each site's terms of service. Disable robots checks only where you have permission.

## Layout
`autosuite/` - `organizer.py`, `scraper.py`, `emailer.py`, `monitor.py`, `scheduler.py`, `tasks.py` (shared task registry), `cli.py`, `gui.py`, `config.py`.
Adding a tool: write a function `fn(args: dict) -> str` in `tasks.py` and register it in `REGISTRY`; the scheduler picks it up.
