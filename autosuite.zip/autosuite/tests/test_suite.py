import os
import tempfile
import unittest
from datetime import datetime, timedelta
from pathlib import Path

os.environ["AUTOSUITE_HOME"] = tempfile.mkdtemp()

from autosuite import emailer, monitor, organizer, scraper  # noqa: E402
from autosuite.scheduler import JobStore, compute_next, parse_duration  # noqa: E402


class OrganizerTests(unittest.TestCase):
    def test_organize_and_undo(self):
        d = Path(tempfile.mkdtemp())
        (d / "a.jpg").write_text("x")
        (d / "b.pdf").write_text("y")
        (d / "c.xyz").write_text("z")
        preview = organizer.organize(d, dry_run=True)
        self.assertEqual(len(preview), 3)
        self.assertTrue((d / "a.jpg").exists())
        organizer.organize(d)
        self.assertTrue((d / "Images" / "a.jpg").exists())
        self.assertTrue((d / "Other" / "c.xyz").exists())
        self.assertEqual(organizer.undo_last(), 3)
        self.assertTrue((d / "a.jpg").exists())
        self.assertFalse((d / "Images").exists())

    def test_duplicates(self):
        d = Path(tempfile.mkdtemp())
        (d / "1.txt").write_text("same")
        (d / "2.txt").write_text("same")
        (d / "3.txt").write_text("different")
        groups = organizer.find_duplicates(d)
        self.assertEqual(len(groups), 1)
        organizer.quarantine_duplicates(groups, d / "dupes")
        self.assertEqual(len(list((d / "dupes").iterdir())), 1)


class ScraperTests(unittest.TestCase):
    def test_parse(self):
        html = ("<html><head><title>Hi</title><meta name='description' content='d'></head><body>"
                "<h1>Head</h1><a href='/x'>link</a><script>bad()</script>"
                "<table><tr><th>a</th><th>b</th></tr><tr><td>1</td><td>2</td></tr></table></body></html>")
        r = scraper.parse(html, "http://e.com/")
        self.assertEqual(r["title"], "Hi")
        self.assertEqual(r["links"][0]["url"], "http://e.com/x")
        self.assertEqual(r["tables"][0], [["a", "b"], ["1", "2"]])
        self.assertNotIn("bad()", r["text"])


class EmailTests(unittest.TestCase):
    def test_dry_run_bulk(self):
        p = Path(tempfile.mkdtemp()) / "l.csv"
        p.write_text("email,name\na@x.com,Ann\nb@x.com,Bob\n")
        out = emailer.send_bulk(str(p), "Hi $name", "Body", dry_run=True, cfg={"from_addr": "me@x.com"})
        self.assertEqual(out, ["[dry-run] a@x.com: Hi Ann", "[dry-run] b@x.com: Hi Bob"])


class MonitorTests(unittest.TestCase):
    def test_snapshot_and_alerts(self):
        s = monitor.snapshot()
        self.assertIn("disk_percent", s)
        self.assertTrue(monitor.check_thresholds({"cpu_percent": 99}, {"cpu_percent": 90}))


class SchedulerTests(unittest.TestCase):
    def test_durations_and_next(self):
        self.assertEqual(parse_duration("15m"), 900)
        now = datetime(2026, 1, 1, 10, 0)
        self.assertEqual(compute_next({"type": "daily", "at": "09:00"}, now), datetime(2026, 1, 2, 9, 0))
        self.assertEqual(compute_next({"type": "interval", "seconds": 60}, now), now + timedelta(minutes=1))

    def test_run_due(self):
        store = JobStore(Path(tempfile.mkdtemp()) / "jobs.json")
        store.add("echo", "shell", {"command": "echo hello"}, {"type": "interval", "seconds": 60})
        self.assertEqual(store.run_due(), [])
        results = store.run_due(datetime.now() + timedelta(minutes=2))
        self.assertEqual(results, [("echo", True, "hello")])


if __name__ == "__main__":
    unittest.main()
