"""System monitoring. Uses psutil when installed, falls back to the stdlib."""
import csv
import os
import shutil
import time
import urllib.request
from datetime import datetime
from pathlib import Path

from . import config

try:
    import psutil
except ImportError:  # optional dependency
    psutil = None


def _mem_percent():
    if psutil:
        return psutil.virtual_memory().percent
    try:
        info = {}
        for line in open("/proc/meminfo"):
            k, v = line.split(":")
            info[k] = int(v.split()[0])
        return round(100 * (1 - info["MemAvailable"] / info["MemTotal"]), 1)
    except Exception:
        return None


def _cpu_percent():
    if psutil:
        return psutil.cpu_percent(interval=0.5)
    try:
        return round(min(100.0, os.getloadavg()[0] / (os.cpu_count() or 1) * 100), 1)
    except (AttributeError, OSError):
        return None


def snapshot(disk_path=None):
    disk_path = disk_path or os.path.abspath(os.sep)
    du = shutil.disk_usage(disk_path)
    snap = {
        "time": datetime.now().isoformat(timespec="seconds"),
        "cpu_percent": _cpu_percent(),
        "mem_percent": _mem_percent(),
        "disk_percent": round(du.used / du.total * 100, 1),
        "disk_free_gb": round(du.free / 1e9, 1),
        "cpu_count": os.cpu_count(),
    }
    if hasattr(os, "getloadavg"):
        try:
            snap["load_avg_1m"] = round(os.getloadavg()[0], 2)
        except OSError:
            pass
    if psutil:
        snap["uptime_hours"] = round((time.time() - psutil.boot_time()) / 3600, 1)
    return snap


def top_processes(n=5):
    if not psutil:
        return []
    procs = []
    for p in psutil.process_iter(["pid", "name", "cpu_percent", "memory_percent"]):
        procs.append(p.info)
    return sorted(procs, key=lambda i: (i["memory_percent"] or 0), reverse=True)[:n]


def check_thresholds(snap, thresholds=None):
    t = thresholds or config.load()["monitor"]
    alerts = []
    for key, label in (("cpu_percent", "CPU"), ("mem_percent", "Memory"), ("disk_percent", "Disk")):
        val, limit = snap.get(key), t.get(key)
        if val is not None and limit is not None and val >= limit:
            alerts.append(f"{label} at {val}% (limit {limit}%)")
    return alerts


def check_urls(urls, timeout=10):
    results = []
    for url in urls:
        start = time.time()
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "AutoSuite-monitor"})
            with urllib.request.urlopen(req, timeout=timeout) as r:
                status = r.status
        except Exception as exc:
            status = str(getattr(exc, "code", exc))
        results.append({"url": url, "status": status, "ms": round((time.time() - start) * 1000)})
    return results


def format_snapshot(snap):
    return "\n".join(f"{k:>14}: {v}" for k, v in snap.items())


def watch(interval=5, count=None, log_path=None, on_snapshot=None, on_alert=None, stop=lambda: False):
    """Poll repeatedly. Optionally log to CSV and call callbacks."""
    n = 0
    writer = fh = None
    if log_path:
        Path(log_path).expanduser().parent.mkdir(parents=True, exist_ok=True)
        fh = open(Path(log_path).expanduser(), "a", newline="")
    try:
        while not stop() and (count is None or n < count):
            snap = snapshot()
            if fh:
                if writer is None:
                    writer = csv.DictWriter(fh, fieldnames=list(snap.keys()), extrasaction="ignore")
                    if fh.tell() == 0:
                        writer.writeheader()
                writer.writerow(snap)
                fh.flush()
            if on_snapshot:
                on_snapshot(snap)
            alerts = check_thresholds(snap)
            if alerts and on_alert:
                on_alert(alerts, snap)
            n += 1
            if count is None or n < count:
                time.sleep(interval)
    finally:
        if fh:
            fh.close()
