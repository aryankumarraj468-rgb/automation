"""Email automation over SMTP (single + CSV-driven bulk with templates)."""
import csv
import mimetypes
import os
import smtplib
import ssl
import time
from email.message import EmailMessage
from pathlib import Path
from string import Template

from . import config


def build_message(cfg, to, subject, body, cc=None, attachments=None, html=False):
    msg = EmailMessage()
    msg["From"] = cfg.get("from_addr") or cfg.get("username")
    msg["To"] = to if isinstance(to, str) else ", ".join(to)
    if cc:
        msg["Cc"] = cc if isinstance(cc, str) else ", ".join(cc)
    msg["Subject"] = subject
    msg.set_content(body, subtype="html" if html else "plain")
    for a in attachments or []:
        p = Path(a).expanduser()
        ctype = mimetypes.guess_type(p.name)[0] or "application/octet-stream"
        main, sub = ctype.split("/", 1)
        msg.add_attachment(p.read_bytes(), maintype=main, subtype=sub, filename=p.name)
    return msg


def _password(cfg):
    return os.environ.get(cfg.get("password_env", ""), "") or cfg.get("password", "")


def _connect(cfg):
    host, port = cfg["smtp_host"], int(cfg["smtp_port"])
    ctx = ssl.create_default_context()
    if port == 465:
        server = smtplib.SMTP_SSL(host, port, context=ctx, timeout=30)
    else:
        server = smtplib.SMTP(host, port, timeout=30)
        server.starttls(context=ctx)
    if cfg.get("username"):
        pw = _password(cfg)
        if not pw:
            raise RuntimeError(f"SMTP password missing: set the {cfg.get('password_env')} environment variable")
        server.login(cfg["username"], pw)
    return server


def send(to, subject, body, cc=None, attachments=None, html=False, dry_run=False, cfg=None):
    cfg = cfg or config.load()["email"]
    msg = build_message(cfg, to, subject, body, cc, attachments, html)
    if dry_run:
        return f"[dry-run] would send to {msg['To']}: {subject}"
    with _connect(cfg) as server:
        server.send_message(msg)
    return f"sent to {msg['To']}: {subject}"


def send_bulk(csv_path, subject_tpl, body_tpl, attachments=None, html=False, dry_run=False, cfg=None):
    """CSV needs an 'email' column; other columns are available as $placeholders."""
    cfg = cfg or config.load()["email"]
    results = []
    with open(csv_path, newline="", encoding="utf-8-sig") as fh:
        rows = list(csv.DictReader(fh))
    if rows and "email" not in rows[0]:
        raise ValueError("CSV must have an 'email' column")
    server = None if dry_run else _connect(cfg)
    try:
        for row in rows:
            subj = Template(subject_tpl).safe_substitute(row)
            body = Template(body_tpl).safe_substitute(row)
            if dry_run:
                results.append(f"[dry-run] {row['email']}: {subj}")
                continue
            try:
                server.send_message(build_message(cfg, row["email"], subj, body, None, attachments, html))
                results.append(f"sent {row['email']}")
            except Exception as exc:  # keep going on per-recipient failures
                results.append(f"FAILED {row['email']}: {exc}")
            time.sleep(float(cfg.get("delay_between_bulk_seconds", 1)))
    finally:
        if server:
            server.quit()
    return results
