"""Persistent job scheduler (interval and daily jobs) with a simple daemon loop."""
import json
import re
import time
import uuid
from datetime import datetime, timedelta

from . import config
from .tasks import REGISTRY

JOBS_FILE = config.HOME / "jobs.json"
HISTORY_FILE = config.HOME / "history.log"
_UNITS = {"s": 1, "m": 60, "h": 3600, "d": 86400}


def parse_duration(text):
    m = re.fullmatch(r"(\d+)\s*([smhd])", text.strip().lower())
    if not m:
        raise ValueError("Duration must look like 30s, 15m, 2h or 1d")
    return int(m.group(1)) * _UNITS[m.group(2)]


def compute_next(schedule, after=None):
    after = after or datetime.now()
    if schedule["type"] == "interval":
        return after + timedelta(seconds=schedule["seconds"])
    if schedule["type"] == "daily":
        h, m = map(int, schedule["at"].split(":"))
        cand = after.replace(hour=h, minute=m, second=0, microsecond=0)
        return cand if cand > after else cand + timedelta(days=1)
    raise ValueError("Unknown schedule type")


class JobStore:
    def __init__(self, path=None):
        self.path = path or JOBS_FILE

    def load(self):
        try:
            return json.loads(self.path.read_text())
        except (OSError, json.JSONDecodeError):
            return []

    def save(self, jobs):
        config.ensure_home()
        self.path.write_text(json.dumps(jobs, indent=2))

    def add(self, name, task, args, schedule):
        if task not in REGISTRY:
            raise ValueError(f"Unknown task '{task}'. Choose from: {', '.join(REGISTRY)}")
        if schedule["type"] == "daily":
            datetime.strptime(schedule["at"], "%H:%M")
        job = {"id": uuid.uuid4().hex[:8], "name": name, "task": task, "args": args,
               "schedule": schedule, "enabled": True, "last_run": None, "last_status": None,
               "next_run": compute_next(schedule).isoformat(timespec="seconds")}
        jobs = self.load()
        jobs.append(job)
        self.save(jobs)
        return job

    def remove(self, ident):
        jobs = self.load()
        keep = [j for j in jobs if ident not in (j["id"], j["name"])]
        self.save(keep)
        return len(jobs) - len(keep)

    def set_enabled(self, ident, enabled):
        jobs = self.load()
        n = 0
        for j in jobs:
            if ident in (j["id"], j["name"]):
                j["enabled"] = enabled
                if enabled:
                    j["next_run"] = compute_next(j["schedule"]).isoformat(timespec="seconds")
                n += 1
        self.save(jobs)
        return n

    def run_job(self, job):
        """Execute one job and record the outcome. Returns (ok, message)."""
        start = datetime.now()
        try:
            msg, ok = REGISTRY[job["task"]](job["args"]), True
        except Exception as exc:
            msg, ok = f"{type(exc).__name__}: {exc}", False
        self._log(job, ok, msg)
        jobs = self.load()
        for j in jobs:
            if j["id"] == job["id"]:
                j["last_run"] = start.isoformat(timespec="seconds")
                j["last_status"] = ("ok: " if ok else "FAILED: ") + msg[:200]
                j["next_run"] = compute_next(j["schedule"]).isoformat(timespec="seconds")
        self.save(jobs)
        return ok, msg

    def run_by_name(self, ident):
        for j in self.load():
            if ident in (j["id"], j["name"]):
                return self.run_job(j)
        raise KeyError(f"No job '{ident}'")

    def run_due(self, now=None):
        now = now or datetime.now()
        results = []
        for j in self.load():
            if j["enabled"] and datetime.fromisoformat(j["next_run"]) <= now:
                results.append((j["name"],) + self.run_job(j))
        return results

    @staticmethod
    def _log(job, ok, msg):
        config.ensure_home()
        with open(HISTORY_FILE, "a", encoding="utf-8") as fh:
            fh.write(f"{datetime.now().isoformat(timespec='seconds')}\t{job['name']}\t"
                     f"{'OK' if ok else 'FAIL'}\t{msg}\n")

    def history(self, n=20):
        try:
            return HISTORY_FILE.read_text(encoding="utf-8").splitlines()[-n:]
        except OSError:
            return []


def daemon(store=None, poll=15, on_result=None, stop=lambda: False):
    store = store or JobStore()
    while not stop():
        for name, ok, msg in store.run_due():
            if on_result:
                on_result(name, ok, msg)
        for _ in range(int(poll)):
            if stop():
                return
            time.sleep(1)
