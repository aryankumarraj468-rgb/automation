"""Tkinter GUI. Long-running work happens in threads; output goes to each tab's log."""
import json
import queue
import threading
import tkinter as tk
from tkinter import filedialog, messagebox, scrolledtext, ttk

from . import config, emailer, monitor, organizer, scraper
from .scheduler import JobStore, daemon, parse_duration
from .tasks import REGISTRY


class LogTab(ttk.Frame):
    """Base tab with a log pane and a thread-safe `run_async` helper."""

    def __init__(self, master):
        super().__init__(master, padding=10)
        self.q = queue.Queue()
        self.form = ttk.Frame(self)
        self.form.pack(fill="x")
        self.log = scrolledtext.ScrolledText(self, height=14, state="disabled", font=("Courier", 10))
        self.log.pack(fill="both", expand=True, pady=(10, 0))
        self.after(150, self._pump)

    def write(self, text):
        self.q.put(str(text))

    def _pump(self):
        try:
            while True:
                text = self.q.get_nowait()
                self.log.config(state="normal")
                self.log.insert("end", text + "\n")
                self.log.see("end")
                self.log.config(state="disabled")
        except queue.Empty:
            pass
        self.after(150, self._pump)

    def run_async(self, fn):
        def runner():
            try:
                fn()
            except Exception as exc:
                self.write(f"error: {exc}")
        threading.Thread(target=runner, daemon=True).start()

    def row(self, r, label, widget):
        ttk.Label(self.form, text=label).grid(row=r, column=0, sticky="w", pady=2, padx=(0, 8))
        widget.grid(row=r, column=1, sticky="ew", pady=2)
        self.form.columnconfigure(1, weight=1)
        return widget


class OrganizerTab(LogTab):
    def __init__(self, master):
        super().__init__(master)
        self.folder = tk.StringVar()
        self.by = tk.StringVar(value="type")
        self.rec = tk.BooleanVar()
        self.dry = tk.BooleanVar(value=True)
        box = ttk.Frame(self.form)
        ttk.Entry(box, textvariable=self.folder).pack(side="left", fill="x", expand=True)
        ttk.Button(box, text="Browse", command=lambda: self.folder.set(filedialog.askdirectory() or self.folder.get())).pack(side="left", padx=4)
        self.row(0, "Folder", box)
        self.row(1, "Organize by", ttk.Combobox(self.form, textvariable=self.by, values=["type", "date", "extension"], state="readonly"))
        opts = ttk.Frame(self.form)
        ttk.Checkbutton(opts, text="Include subfolders", variable=self.rec).pack(side="left")
        ttk.Checkbutton(opts, text="Dry run (preview only)", variable=self.dry).pack(side="left", padx=12)
        self.row(2, "Options", opts)
        btns = ttk.Frame(self.form)
        ttk.Button(btns, text="Run", command=self.run).pack(side="left")
        ttk.Button(btns, text="Undo last", command=self.undo).pack(side="left", padx=6)
        ttk.Button(btns, text="Find duplicates", command=self.dupes).pack(side="left")
        self.row(3, "", btns)

    def run(self):
        def job():
            moves = organizer.organize(self.folder.get(), self.by.get(), recursive=self.rec.get(), dry_run=self.dry.get())
            for s, d in moves:
                self.write(f"{'would move' if self.dry.get() else 'moved'}: {s.name} -> {d.parent.name}/")
            self.write(f"{len(moves)} file(s)")
        self.run_async(job)

    def undo(self):
        self.run_async(lambda: self.write(f"restored {organizer.undo_last()} file(s)"))

    def dupes(self):
        def job():
            groups = organizer.find_duplicates(self.folder.get())
            for g in groups:
                self.write("duplicates:\n  " + "\n  ".join(map(str, g)))
            self.write(f"{len(groups)} duplicate group(s)")
        self.run_async(job)


class ScraperTab(LogTab):
    def __init__(self, master):
        super().__init__(master)
        self.url = tk.StringVar(value="https://")
        self.what = tk.StringVar(value="summary")
        self.out = tk.StringVar()
        self.row(0, "URL", ttk.Entry(self.form, textvariable=self.url))
        self.row(1, "Extract", ttk.Combobox(self.form, textvariable=self.what, state="readonly",
                 values=["summary", "title", "text", "links", "images", "headings", "tables", "meta", "all"]))
        self.row(2, "Save to (optional)", ttk.Entry(self.form, textvariable=self.out))
        self.row(3, "", ttk.Button(self.form, text="Scrape", command=self.run))

    def run(self):
        def job():
            data = scraper.scrape(self.url.get(), self.what.get())
            if self.out.get():
                self.write(f"saved to {scraper.save(data, self.out.get())}")
            self.write(data if isinstance(data, str) else json.dumps(data, indent=2, ensure_ascii=False)[:20000])
        self.run_async(job)


class EmailTab(LogTab):
    def __init__(self, master):
        super().__init__(master)
        cfg = config.load()["email"]
        self.vars = {k: tk.StringVar(value=str(cfg[k])) for k in ("smtp_host", "smtp_port", "username", "from_addr")}
        for i, (k, label) in enumerate((("smtp_host", "SMTP host"), ("smtp_port", "SMTP port"),
                                         ("username", "Username"), ("from_addr", "From"))):
            self.row(i, label, ttk.Entry(self.form, textvariable=self.vars[k]))
        self.row(4, "", ttk.Label(self.form, text=f"Password: set env var {cfg['password_env']}"))
        ttk.Button(self.form, text="Save settings", command=self.save_cfg).grid(row=5, column=1, sticky="w")
        self.to, self.subject, self.attach = tk.StringVar(), tk.StringVar(), tk.StringVar()
        self.dry = tk.BooleanVar(value=True)
        self.row(6, "To", ttk.Entry(self.form, textvariable=self.to))
        self.row(7, "Subject", ttk.Entry(self.form, textvariable=self.subject))
        self.row(8, "Attachments (comma-sep)", ttk.Entry(self.form, textvariable=self.attach))
        self.body = tk.Text(self.form, height=5)
        self.row(9, "Body", self.body)
        opts = ttk.Frame(self.form)
        ttk.Checkbutton(opts, text="Dry run", variable=self.dry).pack(side="left")
        ttk.Button(opts, text="Send", command=self.send).pack(side="left", padx=12)
        self.row(10, "", opts)

    def save_cfg(self):
        cfg = config.load()
        for k, v in self.vars.items():
            cfg["email"][k] = int(v.get()) if k == "smtp_port" else v.get()
        config.save(cfg)
        self.write("settings saved")

    def send(self):
        atts = [a.strip() for a in self.attach.get().split(",") if a.strip()]
        body, to, subj, dry = self.body.get("1.0", "end").strip(), self.to.get(), self.subject.get(), self.dry.get()
        self.run_async(lambda: self.write(emailer.send(to, subj, body, attachments=atts, dry_run=dry)))


class MonitorTab(LogTab):
    def __init__(self, master):
        super().__init__(master)
        self.stop_flag = threading.Event()
        self.interval = tk.StringVar(value="5")
        self.row(0, "Interval (s)", ttk.Entry(self.form, textvariable=self.interval))
        btns = ttk.Frame(self.form)
        ttk.Button(btns, text="Snapshot", command=self.snap).pack(side="left")
        ttk.Button(btns, text="Start live watch", command=self.start).pack(side="left", padx=6)
        ttk.Button(btns, text="Stop", command=self.stop_flag.set).pack(side="left")
        self.row(1, "", btns)

    def snap(self):
        def job():
            s = monitor.snapshot()
            self.write(monitor.format_snapshot(s))
            for a in monitor.check_thresholds(s):
                self.write("ALERT: " + a)
        self.run_async(job)

    def start(self):
        self.stop_flag.clear()
        interval = float(self.interval.get() or 5)
        self.run_async(lambda: monitor.watch(
            interval, on_snapshot=lambda s: self.write(f"{s['time']}  cpu {s['cpu_percent']}%  mem {s['mem_percent']}%  disk {s['disk_percent']}%"),
            on_alert=lambda al, s: self.write("  ALERT: " + "; ".join(al)), stop=self.stop_flag.is_set))


class SchedulerTab(LogTab):
    def __init__(self, master):
        super().__init__(master)
        self.store = JobStore()
        self.stop_flag = threading.Event()
        self.name, self.task = tk.StringVar(), tk.StringVar(value="monitor")
        self.kind, self.value, self.args = tk.StringVar(value="every"), tk.StringVar(value="30m"), tk.StringVar()
        self.row(0, "Job name", ttk.Entry(self.form, textvariable=self.name))
        self.row(1, "Task", ttk.Combobox(self.form, textvariable=self.task, values=list(REGISTRY), state="readonly"))
        sch = ttk.Frame(self.form)
        ttk.Combobox(sch, textvariable=self.kind, values=["every", "daily at"], state="readonly", width=9).pack(side="left")
        ttk.Entry(sch, textvariable=self.value, width=10).pack(side="left", padx=6)
        ttk.Label(sch, text="(30s/15m/2h/1d  or  HH:MM)").pack(side="left")
        self.row(2, "Schedule", sch)
        self.row(3, "Args (k=v, k=v)", ttk.Entry(self.form, textvariable=self.args))
        btns = ttk.Frame(self.form)
        for text, cmd in (("Add job", self.add), ("List", self.list), ("Run selected now", self.run_now),
                          ("Remove", self.remove), ("Start daemon", self.start), ("Stop daemon", self.stop_flag.set)):
            ttk.Button(btns, text=text, command=cmd).pack(side="left", padx=2)
        self.row(4, "", btns)

    def add(self):
        try:
            args = dict(p.strip().split("=", 1) for p in self.args.get().split(",") if "=" in p)
            sched = ({"type": "interval", "seconds": parse_duration(self.value.get())} if self.kind.get() == "every"
                     else {"type": "daily", "at": self.value.get()})
            job = self.store.add(self.name.get(), self.task.get(), args, sched)
            self.write(f"added {job['name']} ({job['id']}), next run {job['next_run']}")
        except Exception as exc:
            messagebox.showerror("Cannot add job", str(exc))

    def list(self):
        for j in self.store.load():
            self.write(f"{j['id']} {'on ' if j['enabled'] else 'off'} {j['name']:<18} {j['task']:<9} next {j['next_run']} | {j['last_status']}")

    def run_now(self):  # runs the job named in the "Job name" box
        self.run_async(lambda: self.write("%s: %s" % ("OK" if (r := self.store.run_by_name(self.name.get()))[0] else "FAILED", r[1])))

    def remove(self):
        self.write(f"removed {self.store.remove(self.name.get())} job(s)")

    def start(self):
        self.stop_flag.clear()
        self.write("daemon started")
        self.run_async(lambda: daemon(self.store, 10, lambda n, ok, m: self.write(f"[{n}] {'OK' if ok else 'FAIL'}: {m}"), self.stop_flag.is_set))


def launch():
    root = tk.Tk()
    root.title("AutoSuite")
    root.geometry("820x640")
    nb = ttk.Notebook(root)
    nb.pack(fill="both", expand=True)
    for title, cls in (("Files", OrganizerTab), ("Scraper", ScraperTab), ("Email", EmailTab),
                       ("Monitor", MonitorTab), ("Scheduler", SchedulerTab)):
        nb.add(cls(nb), text=title)
    root.mainloop()
