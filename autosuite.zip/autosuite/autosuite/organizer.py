"""File organizer: sort by type/date/extension, undo, and duplicate finder."""
import hashlib
import json
import shutil
from collections import defaultdict
from datetime import datetime
from pathlib import Path

from . import config

CATEGORIES = {
    "Images": [".jpg", ".jpeg", ".png", ".gif", ".bmp", ".webp", ".svg", ".heic", ".tiff"],
    "Documents": [".pdf", ".doc", ".docx", ".txt", ".rtf", ".odt", ".md", ".epub"],
    "Spreadsheets": [".xls", ".xlsx", ".csv", ".ods", ".tsv"],
    "Presentations": [".ppt", ".pptx", ".odp", ".key"],
    "Audio": [".mp3", ".wav", ".flac", ".aac", ".ogg", ".m4a"],
    "Video": [".mp4", ".mkv", ".avi", ".mov", ".wmv", ".webm"],
    "Archives": [".zip", ".rar", ".7z", ".tar", ".gz", ".bz2", ".xz"],
    "Code": [".py", ".js", ".ts", ".html", ".css", ".java", ".c", ".cpp", ".go", ".rs", ".json", ".sh", ".sql"],
    "Installers": [".exe", ".msi", ".dmg", ".deb", ".rpm", ".apk"],
}
UNDO_FILE = config.HOME / "undo.json"


def category_for(path, categories=None):
    ext = Path(path).suffix.lower()
    for name, exts in (categories or CATEGORIES).items():
        if ext in exts:
            return name
    return "Other"


def _unique(path):
    if not path.exists():
        return path
    i = 1
    while True:
        cand = path.with_name(f"{path.stem} ({i}){path.suffix}")
        if not cand.exists():
            return cand
        i += 1


def _target_dir(f, dest, by, categories):
    if by == "date":
        d = datetime.fromtimestamp(f.stat().st_mtime)
        return dest / f"{d:%Y}" / f"{d:%m}"
    if by == "extension":
        return dest / (f.suffix[1:].upper() or "NoExtension")
    return dest / category_for(f, categories)


def organize(source, by="type", dest=None, recursive=False, dry_run=False, categories=None):
    """Move files into sub-folders. Returns a list of (src, dst) tuples."""
    if by not in ("type", "date", "extension"):
        raise ValueError("by must be 'type', 'date' or 'extension'")
    source = Path(source).expanduser().resolve()
    if not source.is_dir():
        raise NotADirectoryError(f"{source} is not a directory")
    dest = Path(dest).expanduser().resolve() if dest else source
    candidates = source.rglob("*") if recursive else source.iterdir()
    moves = []
    for f in sorted(candidates):
        if not f.is_file() or f.name.startswith("."):
            continue
        target = _target_dir(f, dest, by, categories)
        if f.parent == target:
            continue
        dst = _unique(target / f.name)
        moves.append((f, dst))
        if not dry_run:
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.move(str(f), str(dst))
    if moves and not dry_run:
        _journal([(str(a), str(b)) for a, b in moves])
    return moves


def _journal(batch):
    config.ensure_home()
    try:
        data = json.loads(UNDO_FILE.read_text())
    except (OSError, json.JSONDecodeError):
        data = []
    data.append({"time": datetime.now().isoformat(timespec="seconds"), "moves": batch})
    UNDO_FILE.write_text(json.dumps(data[-20:], indent=1))


def undo_last():
    """Reverse the most recent organize run. Returns number of files restored."""
    try:
        data = json.loads(UNDO_FILE.read_text())
    except (OSError, json.JSONDecodeError):
        return 0
    if not data:
        return 0
    batch = data.pop()
    restored = 0
    for src, dst in reversed(batch["moves"]):
        s, d = Path(src), Path(dst)
        if d.exists() and not s.exists():
            s.parent.mkdir(parents=True, exist_ok=True)
            shutil.move(str(d), str(s))
            restored += 1
            try:  # remove now-empty folders
                p = d.parent
                while p != s.parent and not any(p.iterdir()):
                    p.rmdir()
                    p = p.parent
            except OSError:
                pass
    UNDO_FILE.write_text(json.dumps(data, indent=1))
    return restored


def _sha256(path, chunk=1 << 20):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        while block := fh.read(chunk):
            h.update(block)
    return h.hexdigest()


def find_duplicates(folder, recursive=True):
    """Return a list of groups (lists of Paths) with identical content."""
    folder = Path(folder).expanduser()
    files = [p for p in (folder.rglob("*") if recursive else folder.iterdir()) if p.is_file()]
    by_size = defaultdict(list)
    for p in files:
        try:
            by_size[p.stat().st_size].append(p)
        except OSError:
            pass
    groups = defaultdict(list)
    for size, paths in by_size.items():
        if len(paths) < 2 or size == 0:
            continue
        for p in paths:
            try:
                groups[_sha256(p)].append(p)
            except OSError:
                pass
    return [sorted(g) for g in groups.values() if len(g) > 1]


def quarantine_duplicates(groups, target, dry_run=False):
    """Keep the first file of every group; move the rest to `target`."""
    target = Path(target).expanduser()
    moved = []
    for g in groups:
        for p in g[1:]:
            dst = _unique(target / p.name)
            moved.append((p, dst))
            if not dry_run:
                dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.move(str(p), str(dst))
    return moved
