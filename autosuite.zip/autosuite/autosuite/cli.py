"""Command-line interface: `python -m autosuite <command>`."""
import argparse
import json
import sys

from . import __version__, config, emailer, monitor, organizer, scraper
from .scheduler import JobStore, daemon, parse_duration
from .tasks import REGISTRY


def _kv(items):
    out = {}
    for item in items or []:
        if "=" not in item:
            raise SystemExit(f"--arg expects key=value, got '{item}'")
        k, v = item.split("=", 1)
        out[k] = v
    return out


def build_parser():
    p = argparse.ArgumentParser(prog="autosuite", description="Automation suite: organize, scrape, email, monitor, schedule.")
    p.add_argument("--version", action="version", version=__version__)
    sub = p.add_subparsers(dest="cmd")

    o = sub.add_parser("organize", help="sort files into folders")
    o.add_argument("source", nargs="?")
    o.add_argument("--by", choices=["type", "date", "extension"], default="type")
    o.add_argument("--dest")
    o.add_argument("-r", "--recursive", action="store_true")
    o.add_argument("-n", "--dry-run", action="store_true")
    o.add_argument("--undo", action="store_true", help="revert the last organize run")

    d = sub.add_parser("dupes", help="find duplicate files")
    d.add_argument("folder")
    d.add_argument("--move-to", help="quarantine duplicates (keeps first of each group)")
    d.add_argument("-n", "--dry-run", action="store_true")

    s = sub.add_parser("scrape", help="extract data from a web page")
    s.add_argument("url")
    s.add_argument("--what", default="summary",
                   choices=["summary", "title", "text", "links", "images", "headings", "tables", "meta", "all"])
    s.add_argument("-o", "--output", help="save to .json/.csv/.txt")
    s.add_argument("--ignore-robots", action="store_true")

    e = sub.add_parser("email", help="send email")
    es = e.add_subparsers(dest="email_cmd")
    se = es.add_parser("send")
    se.add_argument("--to", required=True)
    se.add_argument("--subject", required=True)
    se.add_argument("--body", help="body text (or use --body-file)")
    se.add_argument("--body-file")
    se.add_argument("--cc")
    se.add_argument("--attach", action="append")
    se.add_argument("--html", action="store_true")
    se.add_argument("-n", "--dry-run", action="store_true")
    bk = es.add_parser("bulk", help="template mail-merge from CSV")
    bk.add_argument("csv")
    bk.add_argument("--subject", required=True)
    bk.add_argument("--body-file", required=True)
    bk.add_argument("--attach", action="append")
    bk.add_argument("--html", action="store_true")
    bk.add_argument("-n", "--dry-run", action="store_true")
    es.add_parser("setup", help="interactive SMTP settings")

    m = sub.add_parser("monitor", help="system monitoring")
    ms = m.add_subparsers(dest="mon_cmd")
    ms.add_parser("status")
    w = ms.add_parser("watch")
    w.add_argument("--interval", type=float, default=5)
    w.add_argument("--count", type=int)
    w.add_argument("--log", help="append CSV log")
    u = ms.add_parser("urls", help="check website availability")
    u.add_argument("urls", nargs="+")

    sc = sub.add_parser("schedule", help="manage scheduled jobs")
    ss = sc.add_subparsers(dest="sch_cmd")
    a = ss.add_parser("add")
    a.add_argument("name")
    a.add_argument("task", choices=list(REGISTRY))
    g = a.add_mutually_exclusive_group(required=True)
    g.add_argument("--every", help="interval such as 30s, 15m, 2h, 1d")
    g.add_argument("--daily", help="time of day HH:MM")
    a.add_argument("--arg", action="append", help="task argument key=value (repeatable)")
    ss.add_parser("list")
    for name in ("remove", "enable", "disable", "run"):
        x = ss.add_parser(name)
        x.add_argument("job")
    dm = ss.add_parser("daemon", help="run scheduler in the foreground")
    dm.add_argument("--poll", type=int, default=15)
    ss.add_parser("history")

    sub.add_parser("gui", help="launch the graphical interface")
    return p


def _print_json(data):
    print(json.dumps(data, indent=2, ensure_ascii=False) if not isinstance(data, str) else data)


def main(argv=None):
    parser = build_parser()
    args = parser.parse_args(argv)
    if not args.cmd:
        parser.print_help()
        return 0
    try:
        return _dispatch(args, parser)
    except KeyboardInterrupt:
        return 130
    except Exception as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1


def _dispatch(args, parser):
    if args.cmd == "gui":
        from .gui import launch
        launch()
    elif args.cmd == "organize":
        if args.undo:
            print(f"restored {organizer.undo_last()} file(s)")
            return 0
        if not args.source:
            parser.error("organize needs a source folder (or --undo)")
        moves = organizer.organize(args.source, args.by, args.dest, args.recursive, args.dry_run)
        for s, d in moves:
            print(f"{'would move' if args.dry_run else 'moved'}: {s.name} -> {d.parent.name}/")
        print(f"{len(moves)} file(s)")
    elif args.cmd == "dupes":
        groups = organizer.find_duplicates(args.folder)
        for g in groups:
            print("duplicates:\n  " + "\n  ".join(map(str, g)))
        print(f"{len(groups)} duplicate group(s)")
        if args.move_to and groups:
            moved = organizer.quarantine_duplicates(groups, args.move_to, args.dry_run)
            print(f"{'would move' if args.dry_run else 'moved'} {len(moved)} file(s) to {args.move_to}")
    elif args.cmd == "scrape":
        data = scraper.scrape(args.url, args.what, args.ignore_robots)
        if args.output:
            print(f"saved to {scraper.save(data, args.output)}")
        else:
            _print_json(data)
    elif args.cmd == "email":
        if args.email_cmd == "send":
            body = open(args.body_file, encoding="utf-8").read() if args.body_file else (args.body or "")
            print(emailer.send(args.to, args.subject, body, args.cc, args.attach, args.html, args.dry_run))
        elif args.email_cmd == "bulk":
            body = open(args.body_file, encoding="utf-8").read()
            print("\n".join(emailer.send_bulk(args.csv, args.subject, body, args.attach, args.html, args.dry_run)))
        elif args.email_cmd == "setup":
            cfg = config.load()
            e = cfg["email"]
            e["smtp_host"] = input(f"SMTP host [{e['smtp_host']}]: ") or e["smtp_host"]
            e["smtp_port"] = int(input(f"SMTP port [{e['smtp_port']}]: ") or e["smtp_port"])
            e["username"] = input(f"Username [{e['username']}]: ") or e["username"]
            e["from_addr"] = input(f"From address [{e['from_addr'] or e['username']}]: ") or e["from_addr"] or e["username"]
            config.save(cfg)
            print(f"Saved. Provide the password via the {e['password_env']} environment variable "
                  "(it is never written to disk).")
        else:
            parser.parse_args(["email", "-h"])
    elif args.cmd == "monitor":
        if args.mon_cmd == "status" or args.mon_cmd is None:
            snap = monitor.snapshot()
            print(monitor.format_snapshot(snap))
            for p in monitor.top_processes():
                print(f"  {p['pid']:>7} {str(p['name'])[:25]:<25} mem {p['memory_percent'] or 0:.1f}%")
            for a in monitor.check_thresholds(snap):
                print("ALERT:", a)
        elif args.mon_cmd == "watch":
            monitor.watch(args.interval, args.count, args.log,
                          on_snapshot=lambda s: print(f"{s['time']}  cpu {s['cpu_percent']}%  mem {s['mem_percent']}%  disk {s['disk_percent']}%"),
                          on_alert=lambda al, s: print("  ALERT:", "; ".join(al)))
        elif args.mon_cmd == "urls":
            for r in monitor.check_urls(args.urls):
                print(f"{r['status']!s:>6}  {r['ms']:>5} ms  {r['url']}")
    elif args.cmd == "schedule":
        store = JobStore()
        c = args.sch_cmd
        if c == "add":
            sched = ({"type": "interval", "seconds": parse_duration(args.every)} if args.every
                     else {"type": "daily", "at": args.daily})
            job = store.add(args.name, args.task, _kv(args.arg), sched)
            print(f"added {job['id']} ({job['name']}), next run {job['next_run']}")
        elif c == "list":
            jobs = store.load()
            for j in jobs:
                print(f"{j['id']}  {'on ' if j['enabled'] else 'off'}  {j['name']:<20} {j['task']:<9} next {j['next_run']}  last: {j['last_status']}")
            if not jobs:
                print("no jobs")
        elif c == "remove":
            print(f"removed {store.remove(args.job)} job(s)")
        elif c in ("enable", "disable"):
            print(f"{store.set_enabled(args.job, c == 'enable')} job(s) updated")
        elif c == "run":
            ok, msg = store.run_by_name(args.job)
            print(("OK: " if ok else "FAILED: ") + msg)
            return 0 if ok else 1
        elif c == "daemon":
            print("scheduler running - Ctrl+C to stop")
            daemon(store, args.poll, on_result=lambda n, ok, m: print(f"[{n}] {'OK' if ok else 'FAIL'}: {m}"))
        elif c == "history":
            print("\n".join(store.history()) or "no history")
        else:
            parser.parse_args(["schedule", "-h"])
    return 0
