"""Web scraper using only the standard library."""
import csv
import json
import urllib.request
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import urljoin, urlparse
from urllib.robotparser import RobotFileParser

from . import config

MAX_BYTES = 5 * 1024 * 1024


class _Extractor(HTMLParser):
    def __init__(self, base_url):
        super().__init__(convert_charrefs=True)
        self.base = base_url
        self.title = ""
        self.links, self.images, self.headings, self.tables, self.meta = [], [], [], [], {}
        self.text_parts = []
        self._skip = 0
        self._in_title = False
        self._href = None
        self._link_text = []
        self._heading = None
        self._heading_text = []
        self._table = None
        self._row = None
        self._cell = None

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if tag in ("script", "style", "noscript"):
            self._skip += 1
        elif tag == "title":
            self._in_title = True
        elif tag == "a" and a.get("href"):
            self._href, self._link_text = urljoin(self.base, a["href"]), []
        elif tag == "img" and a.get("src"):
            self.images.append({"src": urljoin(self.base, a["src"]), "alt": a.get("alt", "")})
        elif tag in ("h1", "h2", "h3", "h4", "h5", "h6"):
            self._heading, self._heading_text = tag, []
        elif tag == "meta" and a.get("content"):
            key = a.get("name") or a.get("property")
            if key:
                self.meta[key] = a["content"]
        elif tag == "table":
            self._table = []
        elif tag == "tr" and self._table is not None:
            self._row = []
        elif tag in ("td", "th") and self._row is not None:
            self._cell = []

    def handle_endtag(self, tag):
        if tag in ("script", "style", "noscript"):
            self._skip = max(0, self._skip - 1)
        elif tag == "title":
            self._in_title = False
        elif tag == "a" and self._href:
            self.links.append({"url": self._href, "text": " ".join("".join(self._link_text).split())})
            self._href = None
        elif tag == self._heading:
            self.headings.append({"level": tag, "text": " ".join("".join(self._heading_text).split())})
            self._heading = None
        elif tag in ("td", "th") and self._cell is not None and self._row is not None:
            self._row.append(" ".join("".join(self._cell).split()))
            self._cell = None
        elif tag == "tr" and self._row is not None and self._table is not None:
            if self._row:
                self._table.append(self._row)
            self._row = None
        elif tag == "table" and self._table is not None:
            if self._table:
                self.tables.append(self._table)
            self._table = None

    def handle_data(self, data):
        if self._in_title:
            self.title += data
        if self._skip:
            return
        if self._href is not None:
            self._link_text.append(data)
        if self._heading:
            self._heading_text.append(data)
        if self._cell is not None:
            self._cell.append(data)
        if data.strip():
            self.text_parts.append(data.strip())


def _allowed(url, ua):
    p = urlparse(url)
    rp = RobotFileParser(f"{p.scheme}://{p.netloc}/robots.txt")
    try:
        rp.read()
    except Exception:
        return True
    return rp.can_fetch(ua, url)


def fetch(url, cfg=None):
    cfg = cfg or config.load()["scraper"]
    if urlparse(url).scheme not in ("http", "https"):
        raise ValueError("Only http(s) URLs are supported")
    if cfg.get("respect_robots", True) and not _allowed(url, cfg["user_agent"]):
        raise PermissionError("Blocked by robots.txt (disable with --ignore-robots)")
    req = urllib.request.Request(url, headers={"User-Agent": cfg["user_agent"]})
    with urllib.request.urlopen(req, timeout=cfg.get("timeout", 15)) as r:
        raw = r.read(MAX_BYTES)
        charset = r.headers.get_content_charset() or "utf-8"
    return raw.decode(charset, errors="replace")


def parse(html, base_url=""):
    ex = _Extractor(base_url)
    ex.feed(html)
    return {
        "url": base_url,
        "title": " ".join(ex.title.split()),
        "meta": ex.meta,
        "headings": ex.headings,
        "links": ex.links,
        "images": ex.images,
        "tables": ex.tables,
        "text": "\n".join(ex.text_parts),
    }


def scrape(url, what="summary", ignore_robots=False):
    cfg = dict(config.load()["scraper"])
    if ignore_robots:
        cfg["respect_robots"] = False
    data = parse(fetch(url, cfg), url)
    if what == "summary":
        return {"url": url, "title": data["title"], "description": data["meta"].get("description", ""),
                "headings": len(data["headings"]), "links": len(data["links"]),
                "images": len(data["images"]), "tables": len(data["tables"]),
                "words": len(data["text"].split())}
    if what == "all":
        return data
    if what not in data:
        raise ValueError(f"Unknown extract type '{what}'")
    return data[what]


def save(data, path):
    """Save as .json, .csv or .txt depending on the extension."""
    path = Path(path).expanduser()
    path.parent.mkdir(parents=True, exist_ok=True)
    ext = path.suffix.lower()
    if ext == ".csv":
        rows = data
        if isinstance(data, dict):
            rows = [{"key": k, "value": v} for k, v in data.items()]
        with open(path, "w", newline="", encoding="utf-8") as fh:
            w = csv.writer(fh)
            if rows and isinstance(rows[0], dict):
                w.writerow(rows[0].keys())
                w.writerows([r.values() for r in rows])
            elif rows and isinstance(rows[0], list) and rows[0] and isinstance(rows[0][0], list):
                for t in rows:  # list of tables
                    w.writerows(t)
                    w.writerow([])
            else:
                w.writerows(rows if rows and isinstance(rows[0], list) else [[r] for r in rows])
    elif ext == ".json":
        path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    else:
        path.write_text(data if isinstance(data, str) else json.dumps(data, indent=2, ensure_ascii=False),
                        encoding="utf-8")
    return path
