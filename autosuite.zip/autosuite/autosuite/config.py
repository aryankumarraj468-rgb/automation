"""Configuration handling. Data lives in ~/.autosuite (override with AUTOSUITE_HOME)."""
import copy
import json
import os
from pathlib import Path

HOME = Path(os.environ.get("AUTOSUITE_HOME", Path.home() / ".autosuite"))
CONFIG_FILE = HOME / "config.json"

DEFAULTS = {
    "email": {
        "smtp_host": "smtp.gmail.com",
        "smtp_port": 587,
        "username": "",
        "from_addr": "",
        "password_env": "AUTOSUITE_SMTP_PASSWORD",  # password is read from this env var
        "delay_between_bulk_seconds": 1.0,
    },
    "monitor": {
        "cpu_percent": 90,
        "mem_percent": 90,
        "disk_percent": 90,
        "alert_email_to": "",
    },
    "scraper": {
        "user_agent": "AutoSuite/1.0 (+personal automation)",
        "timeout": 15,
        "respect_robots": True,
    },
}


def _merge(base, over):
    for k, v in over.items():
        if isinstance(v, dict) and isinstance(base.get(k), dict):
            _merge(base[k], v)
        else:
            base[k] = v
    return base


def ensure_home():
    HOME.mkdir(parents=True, exist_ok=True)
    return HOME


def load():
    cfg = copy.deepcopy(DEFAULTS)
    if CONFIG_FILE.exists():
        try:
            _merge(cfg, json.loads(CONFIG_FILE.read_text(encoding="utf-8")))
        except (json.JSONDecodeError, OSError):
            pass
    return cfg


def save(cfg):
    ensure_home()
    CONFIG_FILE.write_text(json.dumps(cfg, indent=2), encoding="utf-8")
