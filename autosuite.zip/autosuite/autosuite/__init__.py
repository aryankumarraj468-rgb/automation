"""AutoSuite - file organizer, web scraper, emailer, system monitor and scheduler."""
__version__ = "1.0.0"
