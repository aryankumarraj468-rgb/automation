"""Task registry: every task takes a dict of args and returns a short result string."""
import subprocess

from . import config, emailer, monitor, organizer, scraper


def _as_bool(v):
    return v if isinstance(v, bool) else str(v).lower() in ("1", "true", "yes", "y")


def organize_task(a):
    moves = organizer.organize(a["source"], by=a.get("by", "type"), dest=a.get("dest"),
                               recursive=_as_bool(a.get("recursive", False)),
                               dry_run=_as_bool(a.get("dry_run", False)))
    return f"organized {len(moves)} file(s) in {a['source']}"


def scrape_task(a):
    data = scraper.scrape(a["url"], a.get("what", "summary"), _as_bool(a.get("ignore_robots", False)))
    if a.get("output"):
        scraper.save(data, a["output"])
        return f"scraped {a['url']} -> {a['output']}"
    return f"scraped {a['url']}"


def email_task(a):
    atts = [x for x in str(a.get("attachments", "")).split(",") if x]
    return emailer.send(a["to"], a.get("subject", "(no subject)"), a.get("body", ""),
                        attachments=atts, dry_run=_as_bool(a.get("dry_run", False)))


def monitor_task(a):
    snap = monitor.snapshot()
    alerts = monitor.check_thresholds(snap)
    if a.get("log"):
        monitor.watch(count=1, log_path=a["log"])
    if alerts and a.get("email_to"):
        emailer.send(a["email_to"], "AutoSuite alert", "\n".join(alerts) + "\n\n" + monitor.format_snapshot(snap))
    return "ALERT: " + "; ".join(alerts) if alerts else "all clear"


def shell_task(a):
    r = subprocess.run(a["command"], shell=True, capture_output=True, text=True,
                       timeout=int(a.get("timeout", 300)))
    out = (r.stdout or r.stderr).strip().splitlines()
    if r.returncode != 0:
        raise RuntimeError(f"exit {r.returncode}: {out[-1] if out else ''}")
    return out[-1] if out else "ok"


REGISTRY = {
    "organize": organize_task,
    "scrape": scrape_task,
    "email": email_task,
    "monitor": monitor_task,
    "shell": shell_task,
}
